﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using onlinewypoo.Areas.Identity.Data;
using onlinewypoo.Models;
using onlinewypoo.Models.Filmy.Models;

namespace onlinewypoo.Controllers
{
    [Authorize(Roles = "user")]
    public class UserController : Controller
    {
        private readonly AutaDbContext _context;
        private readonly UserManager<onlinewypooUser> _user;

        public UserController(AutaDbContext context, UserManager<onlinewypooUser> user)
        {
            _context = context;
            _user = user;
        }
        public IActionResult Index()
        {
            return View(_context.Autas.ToList());
        }
        // GET: AutaController/Edit/5
        public ActionResult Wypozycz(int id)
        {
            return View(_context.Autas.Find(id));
        }

        // POST: AutaController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Wypozycz(int id, auta car)
        {
            try
            {



                    var user = _user.GetUserAsync(User).Result;
                    var order = new Order
                    {
                        UserId = user.Id,
                        CarId = car.Id,
                        // Dodaj inne właściwości, jeśli są potrzebne
                    };

                //_context.Orders.Add(order);
                    _context.Update(car);
                    _context.SaveChanges();
               

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
