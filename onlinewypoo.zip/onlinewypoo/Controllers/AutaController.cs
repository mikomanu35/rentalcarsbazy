﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using onlinewypoo.Models;
using onlinewypoo.Models.Filmy.Models;

namespace onlinewypoo.Controllers
{
    [Authorize(Roles ="Admin")]
    public class AutaController : Controller
    {
        private readonly AutaDbContext _context;
        public AutaController(AutaDbContext context)
        {
            _context = context;
        }

        // GET: AutaController
        public ActionResult Index()
        {
            return View(_context.Autas.ToList());
        }

        // GET: AutaController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: AutaController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AutaController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(auta car)
        {
            if (ModelState.IsValid)
            {
                _context.Autas.Add(car);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // GET: AutaController/Edit/5
        public ActionResult Edit(int id)
        {
            return View(_context.Autas.Find(id));
        }

        // POST: AutaController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, auta car)
        {
            try
            {
                _context.Autas.Update(car);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AutaController/Delete/5
        public ActionResult Delete(int id)
        {
            return View(_context.Autas.Find(id));
        }

        // POST: AutaController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, auta car)
        {
            try
            {
                _context.Autas.Remove(car);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(); 
            }
        }
    }
}
