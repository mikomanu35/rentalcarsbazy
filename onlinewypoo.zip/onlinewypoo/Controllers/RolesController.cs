﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using onlinewypoo.Areas.Identity.Data;
using onlinewypoo.Models.Filmy.Models;



namespace onlinewypoo.Controllers
{
    [Authorize(Roles = "Admin")]
    public class RolesController : Controller
    {
        
        
        private readonly RoleManager<IdentityRole> _manager;
        private readonly UserManager<onlinewypooUser> _userManager;
        public RolesController(UserManager<onlinewypooUser> userManager, RoleManager<IdentityRole> manager){
            _manager =manager;
            _userManager = userManager;  }


        public IActionResult Index()
        {
            var user = _userManager.Users;
            return View(user);
        }
      
        [HttpPost]
        public async Task<IActionResult> ChangeUserRole(string userId, string newRole)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user != null)
            {
                // Usuń stare role użytkownika
                var oldRoles = await _userManager.GetRolesAsync(user);
                await _userManager.RemoveFromRolesAsync(user, oldRoles);

                // Dodaj nową rolę
                await _userManager.AddToRoleAsync(user, newRole);
            }

            // Przekieruj gdzieś po zakończeniu zmiany roli
            return RedirectToAction("Index");
        }

    }

}
