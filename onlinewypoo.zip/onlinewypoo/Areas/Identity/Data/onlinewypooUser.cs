﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using onlinewypoo.Models;

namespace onlinewypoo.Areas.Identity.Data;

// Add profile data for application users by adding properties to the onlinewypooUser class
public class onlinewypooUser : IdentityUser
{
    public String FirstName { get; set; }
    public String LastName { get; set; }
    public List<Order> Orders { get; set; }
}

