﻿namespace onlinewypoo.Models
{
    using Microsoft.AspNetCore.Identity;
    using Microsoft.EntityFrameworkCore;
    using onlinewypoo.Areas.Identity.Data;

    namespace Filmy.Models
    {
        public class AutaDbContext : DbContext
        {
            public AutaDbContext(DbContextOptions<AutaDbContext> options) :base(options)
            {
            }
           /* protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                base.OnModelCreating(modelBuilder);

                // Definicje relacji
                modelBuilder.Entity<Order>()
                    .HasOne(o => o.User)
                    .WithMany(u => u.Orders)
                    .HasForeignKey(o => o.UserId);

                modelBuilder.Entity<Order>()
                    .HasOne(o => o.Car)
                    .WithMany(c => c.Orders)
                    .HasForeignKey(o => o.CarId);
            }*/
            public DbSet<auta> Autas { get; set; }
            public DbSet<onlinewypooUser> Users { get; set; }
            //public DbSet<Order> Orders { get; set; }
        }
    }

}
