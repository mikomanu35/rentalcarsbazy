﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace onlinewypoo.Models
{
    public class auta
    {
        [Key]
        public int Id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string CarModel { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string CarBrand { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string CarColor { get; set; }
        
        [Column(TypeName = "int")]
        public int Year { get; set; }
        [Column(TypeName = "int")]
        public int Price { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string Availability { get; set; }

        //public List<Order> Orders { get; set; }

    }
}
