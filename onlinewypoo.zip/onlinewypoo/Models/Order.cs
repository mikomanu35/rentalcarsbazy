﻿using Microsoft.AspNetCore.Identity;
using onlinewypoo.Areas.Identity.Data;
using System.ComponentModel.DataAnnotations;

namespace onlinewypoo.Models
{
    public class Order
    {
        [Key]
        public int Id { get; set; }

        // Klucze obce
        public string UserId { get; set; }
        public int CarId { get; set; }

        // Dodatkowe atrybuty zamówienia, jeśli są potrzebne

        // Klucze obce
        public onlinewypooUser User { get; set; }
        public auta Car { get; set; }
    }
}
